source("R/bandit_functions.R")
library(tidyr)
set.seed(1)

raw <- read.csv("data/raw/experiment_log.csv", stringsAsFactors = FALSE)
cleaned <- clean_log(raw); d <- cleaned$data
print(cleaned$log); print(cleaned$missing)
stopifnot(!anyNA(d$visitors), all(d$conversions <= d$visitors))

# ---- 1. How did the bandit allocate traffic over time? -----------------------------------------------------
alloc <- d |> mutate(week = (day - 1) %/% 7 + 1) |> group_by(week, arm) |> summarise(visitors = sum(visitors), .groups = "drop") |>
  group_by(week) |> mutate(share = visitors / sum(visitors)) |> ungroup()
print(alloc |> select(-visitors) |> pivot_wider(names_from = arm, values_from = share))

# ---- 2. Arm summary: rate, Wald interval, Bayesian posterior, P(best), expected loss ------------------------
arm <- d |> group_by(arm) |> summarise(visitors = sum(visitors), conversions = sum(conversions), .groups = "drop") |>
  mutate(rate = conversions / visitors, se = sqrt(rate * (1 - rate) / visitors), lower = rate - 1.96 * se, upper = rate + 1.96 * se)
draws <- sapply(seq_len(nrow(arm)), function(k) rbeta(20000, 1 + arm$conversions[k], 1 + arm$visitors[k] - arm$conversions[k]))
best <- max.col(draws, ties.method = "random")
arm$prob_best <- tabulate(best, nrow(arm)) / length(best)
arm$expected_loss <- sapply(seq_len(nrow(arm)), function(k) mean(apply(draws, 1, max) - draws[, k]))
print(arm)

# ---- 3. Weekday effect and the day-adjusted analysis ------------------------------------------------------------
wk <- d |> group_by(weekend) |> summarise(rate = sum(conversions) / sum(visitors), .groups = "drop")
print(wk)
fit_adj <- glm(cbind(conversions, visitors - conversions) ~ arm + weekend, family = binomial(), data = d)
print(summary(fit_adj)$coefficients)
newd <- tibble(arm = ARMS, weekend = 0L)
arm$adjusted_weekday_rate <- as.vector(predict(fit_adj, newd, type = "response"))
arm$lift_vs_A_naive <- arm$rate / arm$rate[arm$arm == "A"]
arm$lift_vs_A_adjusted <- arm$adjusted_weekday_rate / arm$adjusted_weekday_rate[arm$arm == "A"]
print(arm |> select(arm, rate, adjusted_weekday_rate, lift_vs_A_naive, lift_vs_A_adjusted))

# ---- 4. What would a fixed A/B test have needed? -------------------------------------------------------------------
pw <- power.prop.test(p1 = 0.040, p2 = 0.045, power = 0.8, sig.level = 0.05)
cat("Visitors per arm to detect 4.0% vs 4.5% with 80% power:", ceiling(pw$n), "\n")

saveRDS(list(data = d, log = cleaned$log, missing = cleaned$missing, alloc = alloc, arm = arm, wk = wk,
             coef = summary(fit_adj)$coefficients, n_needed = ceiling(pw$n)), "data/clean/experiment_results.rds")

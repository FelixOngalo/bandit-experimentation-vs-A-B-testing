source("R/bandit_functions.R")
library(tidyr)
set.seed(2)

R <- 1000; days <- 28; V <- 2000
policies_for <- function(sc) c("ab", "peek", "eg", "ts", if (sc == "s3_drift") "tsd")
rows <- list(); k <- 1
for (sc in names(SCENARIOS)) {
  S <- SCENARIOS[[sc]]; best_final <- which.max(S$rate_fun(days))
  for (pol in policies_for(sc)) {
    o <- run_policy(pol, S$rate_fun, S$K, R = R, days = days, V = V)
    win <- decide_winner(pol, o, S$K)
    declared <- !is.na(win)
    rows[[k]] <- tibble(scenario = sc, scenario_label = S$label, policy = pol, policy_label = POLICY_LABELS[[pol]],
      conversions = mean(o$conv), regret = mean(o$regret), regret_se = sd(o$regret) / sqrt(R),
      share_to_best = if (sc == "s1_small_gaps") mean(o$n[, best_final] / rowSums(o$n)) else NA_real_,
      last7_share_to_best = if (sc == "s3_drift") mean(o$last_share) else NA_real_,
      declared = mean(declared), correct = if (sc == "s1_small_gaps") mean(declared & win == best_final, na.rm = TRUE) else NA_real_,
      false_positive = if (sc == "s2_null") mean(declared) else NA_real_)
    k <- k + 1
    cat("done", sc, pol, "\n")
  }
}
results <- bind_rows(rows)
print(results)
saveRDS(list(results = results, R = R, days = days, V = V), "data/clean/policy_results.rds")

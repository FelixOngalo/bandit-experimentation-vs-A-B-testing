source("R/bandit_functions.R")
library(tidyr)
set.seed(3)

# After an adaptive experiment, are the estimates trustworthy? Repeat the Thompson experiment with a weekday effect
# many times and compare the pooled (naive) estimates with a day-adjusted logistic regression.
Rreps <- 300; days <- 28; V <- 2000
dow <- ((seq_len(days) - 1) %% 7) + 1; f <- WEEKDAY_FACTOR[dow]
one_rep <- function() {
  a <- rep(1, 4); b <- rep(1, 4); n <- matrix(0, days, 4); s <- matrix(0, days, 4)
  for (d in seq_len(days)) {
    w <- tabulate(max.col(matrix(rbeta(200 * 4, rep(a, each = 200), rep(b, each = 200)), ncol = 4), ties.method = "random"), 4) / 200
    x <- as.vector(rmultinom(1, V, w)); y <- rbinom(4, x, BASE_RATES * f[d]); n[d, ] <- x; s[d, ] <- y; a <- a + y; b <- b + x - y
  }
  dat <- tibble(arm = factor(rep(ARMS, each = days)), weekend = rep(as.integer(dow >= 6), 4), conversions = as.vector(s), visitors = as.vector(n))
  naive <- colSums(s) / pmax(colSums(n), 1)
  fit <- suppressWarnings(glm(cbind(conversions, visitors - conversions) ~ arm + weekend, family = binomial(), data = dat))
  adj <- as.vector(predict(fit, tibble(arm = factor(ARMS), weekend = 0L), type = "response"))
  # naive 95% Wald interval for the lift of the best-looking arm over arm A
  rate <- naive; se <- sqrt(rate * (1 - rate) / pmax(colSums(n), 1)); i <- which.max(rate)
  diff <- rate[i] - rate[1]; sed <- sqrt(se[i]^2 + se[1]^2)
  tibble(arm = ARMS, naive = naive, adjusted = adj, best_by_naive = i, diff_lower = diff - 1.96 * sed, diff_upper = diff + 1.96 * sed,
         true_diff = BASE_RATES[i] - BASE_RATES[1] * 1)
}
reps <- bind_rows(lapply(seq_len(Rreps), function(r) mutate(one_rep(), rep = r)))
truth <- tibble(arm = ARMS, true_rate = BASE_RATES, true_weekday_avg = BASE_RATES * mean(f))

bias <- reps |> group_by(arm) |> summarise(naive_mean = mean(naive), adjusted_mean = mean(adjusted), .groups = "drop") |>
  left_join(truth, by = "arm") |>
  mutate(naive_bias_pct_vs_pooled_truth = 100 * (naive_mean / true_weekday_avg - 1), adjusted_bias_pct_vs_weekday_truth = 100 * (adjusted_mean / true_rate - 1))
print(bias)

lift <- reps |> select(rep, arm, naive, adjusted) |> pivot_wider(names_from = arm, values_from = c(naive, adjusted)) |>
  summarise(true_lift_D_over_A = BASE_RATES[["D"]] / BASE_RATES[["A"]], naive_lift = mean(naive_D / naive_A), adjusted_lift = mean(adjusted_D / adjusted_A))
print(lift)

wald <- reps |> group_by(rep) |> slice(1) |> ungroup() |>
  summarise(share_best_is_D = mean(best_by_naive == 4), coverage = mean(true_diff >= diff_lower & true_diff <= diff_upper))
print(wald)
saveRDS(list(bias = bias, lift = lift, wald = wald, Rreps = Rreps), "data/clean/bias_results.rds")

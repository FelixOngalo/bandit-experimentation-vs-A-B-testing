# Functions for the bandit-vs-A/B project: replicated simulation of experiment policies, final decisions,
# a simulated traffic log (with realistic mess) and cleaning.

library(dplyr)
library(tibble)

ARMS <- c("A", "B", "C", "D")
POLICY_LABELS <- c(ab = "Fixed A/B (even split)", peek = "A/B with daily peeking",
                   eg = "Epsilon-greedy (10%)", ts = "Thompson sampling", tsd = "Thompson sampling, discounted")

#' Thompson allocation weights: for each replication, the share of M posterior draws in which each arm is best,
#' i.e. a Monte Carlo estimate of P(arm is best).
thompson_weights <- function(a, b, M = 200) {
  R <- nrow(a); K <- ncol(a)
  ar <- a[rep(seq_len(R), each = M), , drop = FALSE]; br <- b[rep(seq_len(R), each = M), , drop = FALSE]
  dr <- matrix(rbeta(R * M * K, ar, br), ncol = K)
  win <- max.col(dr, ties.method = "random")
  matrix(tabulate((rep(seq_len(R), each = M) - 1) * K + win, R * K), R, K, byrow = TRUE) / M
}

#' Best-versus-runner-up two-proportion z statistic for each replication.
top_two_z <- function(s, n) {
  R <- nrow(s); pr <- s / pmax(n, 1)
  ord <- t(apply(pr, 1, order, decreasing = TRUE)); i1 <- ord[, 1]; i2 <- ord[, 2]; r <- seq_len(R)
  p1 <- pr[cbind(r, i1)]; p2 <- pr[cbind(r, i2)]
  se <- sqrt(p1 * (1 - p1) / pmax(n[cbind(r, i1)], 1) + p2 * (1 - p2) / pmax(n[cbind(r, i2)], 1) + 1e-12)
  list(z = (p1 - p2) / se, best = i1)
}

#' Run R independent experiments of `days` days with V visitors a day, updating once a day (batch updating).
#'   rate_fun(d) gives each arm's true conversion rate on day d.
#' Policies: ab (even split), peek (even split, but ships the winner as soon as a daily z-test is significant),
#' eg (10% exploration), ts (Thompson sampling), tsd (Thompson with a 0.9 per-day discount, for drifting rates).
run_policy <- function(policy, rate_fun, K, R = 1000, days = 28, V = 2000, M = 200, gamma = 0.9) {
  a <- matrix(1, R, K); b <- matrix(1, R, K); n <- matrix(0, R, K); s <- matrix(0, R, K)
  conv <- numeric(R); regret <- numeric(R); last <- numeric(R)
  stopped <- rep(FALSE, R); stop_arm <- rep(NA_integer_, R); r <- seq_len(R)
  for (d in seq_len(days)) {
    p <- rate_fun(d)
    w <- switch(policy,
      ab = , peek = matrix(1 / K, R, K),
      eg = { m <- (s + 1) / (n + 2); w0 <- matrix(0.1 / K, R, K); i <- cbind(r, max.col(m, ties.method = "first")); w0[i] <- w0[i] + 0.9; w0 },
      ts = , tsd = thompson_weights(a, b, M))
    if (policy == "peek" && any(stopped)) { w[stopped, ] <- 0; w[cbind(which(stopped), stop_arm[stopped])] <- 1 }   # ship the declared winner
    x <- t(vapply(r, function(i) as.numeric(rmultinom(1, V, w[i, ])), numeric(K)))
    y <- matrix(rbinom(R * K, x, rep(p, each = R)), R, K)
    if (policy == "tsd") { a <- 1 + gamma * (a - 1) + y; b <- 1 + gamma * (b - 1) + (x - y) } else { a <- a + y; b <- b + x - y }
    n <- n + x; s <- s + y
    conv <- conv + rowSums(y); regret <- regret + V * max(p) - as.vector(x %*% p)
    if (d > days - 7) last <- last + x[, which.max(p)]
    if (policy == "peek") {
      tt <- top_two_z(s, n); sig <- !stopped & tt$z > qnorm(0.975)
      stopped[sig] <- TRUE; stop_arm[sig] <- tt$best[sig]
    }
  }
  list(conv = conv, regret = regret, n = n, s = s, a = a, b = b, stopped = stopped, stop_arm = stop_arm,
       last_share = last / (7 * V))
}

#' The winner each policy would declare at the end (NA = no winner declared).
decide_winner <- function(policy, o, K, M = 2000) {
  if (policy == "peek") return(ifelse(o$stopped, o$stop_arm, NA_integer_))
  if (policy %in% c("ts", "tsd")) {
    pb <- thompson_weights(o$a, o$b, M)
    return(ifelse(apply(pb, 1, max) > 0.95, max.col(pb, ties.method = "first"), NA_integer_))
  }
  tt <- top_two_z(o$s, o$n); ifelse(tt$z > qnorm(0.975), tt$best, NA_integer_)
}

SCENARIOS <- list(
  s1_small_gaps = list(K = 4, label = "Small gaps: rates 4.0 / 4.5 / 5.0 / 6.0%", rate_fun = function(d) c(0.040, 0.045, 0.050, 0.060)),
  s2_null = list(K = 4, label = "No difference: every arm 5%", rate_fun = function(d) rep(0.05, 4)),
  s3_drift = list(K = 3, label = "Drift: the best arm changes on day 15", rate_fun = function(d) if (d <= 14) c(0.05, 0.06, 0.04) else c(0.05, 0.04, 0.065)))

# ---- Traffic log of one real-style experiment ---------------------------------------------------------------
WEEKDAY_FACTOR <- c(1, 1, 1, 1, 1, 1.35, 1.35)            # conversion is 35% higher at weekends (all arms)
BASE_RATES <- c(A = 0.040, B = 0.045, C = 0.050, D = 0.060)

#' Simulate one 28-day Thompson-sampling experiment of 2,000 visitors a day and return it as a daily log.
simulate_experiment <- function(seed = 1, days = 28, V = 2000, messy = TRUE) {
  set.seed(seed)
  dates <- as.Date("2026-09-07") + seq_len(days) - 1
  dow <- ((seq_len(days) - 1) %% 7) + 1                      # 2026-09-07 is a Monday
  a <- rep(1, 4); b <- rep(1, 4); rows <- list()
  for (d in seq_len(days)) {
    w <- tabulate(max.col(matrix(rbeta(200 * 4, rep(a, each = 200), rep(b, each = 200)), ncol = 4), ties.method = "random"), 4) / 200
    x <- as.vector(rmultinom(1, V, w)); y <- rbinom(4, x, BASE_RATES * WEEKDAY_FACTOR[dow[d]])
    a <- a + y; b <- b + x - y
    rows[[d]] <- tibble(date = dates[d], arm = ARMS, visitors = x, conversions = y, is_bot = FALSE)
  }
  log <- bind_rows(rows)
  truth <- list(base_rates = BASE_RATES, weekday_factor = WEEKDAY_FACTOR)
  if (messy) {
    bots <- log[log$arm == "B" & log$date >= dates[10] & log$date <= dates[12], ]
    bots$visitors <- 700L; bots$conversions <- 0L; bots$is_bot <- TRUE           # a bot burst on arm B (no conversions)
    log <- bind_rows(log, bots)
    log <- log[-which(log$arm == "C" & log$date == dates[20]), ]                  # logging outage: one arm-day missing
    i_lab <- sample(nrow(log), 8); log$arm[i_lab] <- tolower(log$arm[i_lab])      # inconsistent labels
    log <- bind_rows(log, log[sample(nrow(log), 6), ]) |> arrange(date)           # duplicated rows
  }
  list(log = log, truth = truth)
}

clean_log <- function(raw) {
  n0 <- nrow(raw)
  x <- raw |> mutate(arm = toupper(trimws(arm)), date = as.Date(date)) |> distinct()
  n_dup <- n0 - nrow(x)
  n_bot <- sum(x$visitors[x$is_bot]); x <- x[!x$is_bot, ]
  missing <- anti_join(expand.grid(date = unique(x$date), arm = ARMS, stringsAsFactors = FALSE) |> as_tibble(), x, by = c("date", "arm"))
  x <- x |> mutate(weekend = as.integer(format(date, "%u") %in% c("6", "7")), day = as.integer(date - min(date)) + 1)
  log <- tibble(step = c("Rows received", "Duplicate rows removed", "Bot visitors removed", "Missing arm-days (logging outage)", "Arm-days analysed"),
                value = c(n0, n_dup, n_bot, nrow(missing), nrow(x)))
  list(data = x, log = log, missing = missing)
}

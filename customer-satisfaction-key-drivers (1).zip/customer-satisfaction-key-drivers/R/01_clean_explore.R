source("R/kda_functions.R")
library(tidyr)
set.seed(1)

raw <- read.csv("data/raw/survey_responses.csv", stringsAsFactors = FALSE)
pop <- read.csv("data/raw/customers_by_segment.csv", stringsAsFactors = FALSE)
truth <- readRDS("data/clean/truth.rds")
cleaned <- clean_survey(raw); d <- cleaned$data
print(cleaned$log)
stopifnot(!anyNA(d[ITEMS]), all(d$recommend %in% 0:10))

# ---- 1. Who answered? Response by segment against the customer base --------------------------------
resp <- d |> count(segment, name = "responses") |> left_join(pop, by = "segment") |>
  mutate(response_rate = responses / customers, sample_share = responses / sum(responses), population_share = customers / sum(customers))
print(resp)

# ---- 2. NPS: respondents, segment-weighted, and (simulation only) the true population value ------------
w_seg <- resp$population_share / resp$sample_share; names(w_seg) <- resp$segment
d$w <- w_seg[d$segment]
nps_tbl <- tibble(estimate = c("Respondents, unweighted", "Respondents, weighted to segment mix", "True population NPS (simulation)"),
                  nps = c(nps(d$recommend), nps(d$recommend, d$w), truth$population_nps))
print(nps_tbl)
bootnps <- replicate(1000, { i <- sample(nrow(d), replace = TRUE); nps(d$recommend[i], d$w[i]) })
nps_ci <- quantile(bootnps, c(0.025, 0.975)); print(nps_ci)
nps_seg <- d |> group_by(segment) |> summarise(n = n(), nps = nps(recommend), mean_recommend = mean(recommend), .groups = "drop")
print(nps_seg)

# ---- 3. Performance of each aspect and how the ratings overlap --------------------------------------------
perf <- tibble(item = ITEMS, label = ITEM_LABELS[ITEMS], mean_rating = sapply(ITEMS, function(j) mean(d[[j]])),
               top2box = sapply(ITEMS, function(j) mean(d[[j]] >= 4)))
print(perf)
cor_items <- cor(d[ITEMS])
vif <- tibble(item = ITEMS, vif = diag(solve(cor_items)))
print(vif)
fa <- tryCatch(factanal(d[ITEMS], factors = 3, rotation = "varimax"), error = function(e) NULL)
loadings_tbl <- if (!is.null(fa)) as_tibble(unclass(fa$loadings), rownames = "item") else NULL
print(loadings_tbl)

saveRDS(list(data = d, log = cleaned$log, resp = resp, nps_tbl = nps_tbl, nps_ci = nps_ci, nps_seg = nps_seg, perf = perf,
             cor_items = cor_items, vif = vif, loadings = loadings_tbl), "data/clean/survey_clean.rds")

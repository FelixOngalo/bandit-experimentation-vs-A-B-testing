source("R/kda_functions.R")
library(tidyr)
library(MASS)          # polr (ordinal logistic regression); ships with R
select <- dplyr::select
set.seed(2)

obj <- readRDS("data/clean/survey_clean.rds"); d <- obj$data; perf <- obj$perf
truth <- readRDS("data/clean/truth.rds")
X <- as.matrix(d[ITEMS]); y <- d$recommend

# ---- 1. Five ways to ask "which aspects drive recommendation?" ------------------------------------------------
cors <- cor(X, y)[, 1]
beta <- std_betas(X, y)
rw <- relative_weights(X, y); rw_share <- rw / sum(rw)
fit_ord <- polr(nps_group ~ ., data = data.frame(nps_group = d$nps_group, scale(X)), Hess = TRUE)
ord <- coef(fit_ord)[ITEMS]
stated <- colMeans(d[paste0("imp_", ITEMS)])

drivers <- tibble(item = ITEMS, label = ITEM_LABELS[ITEMS], true_effect = truth$effects$true_effect[match(ITEMS, truth$effects$item)],
                  stated_importance = unname(stated), correlation = unname(cors), std_beta = unname(beta),
                  relative_weight_share = unname(rw_share), ordinal_logit = unname(ord))
print(drivers)
cat("R-squared (OLS):", round(sum(rw), 3), "\n")

# ---- 2. Grading against the truth ------------------------------------------------------------------------------------
method_cols <- c("stated_importance", "correlation", "std_beta", "relative_weight_share", "ordinal_logit")
true_top3 <- ITEMS[order(-drivers$true_effect)][1:3]
grade <- tibble(method = method_cols,
  spearman_with_true = sapply(method_cols, function(m) cor(drivers[[m]], drivers$true_effect, method = "spearman")),
  top3_correct = sapply(method_cols, function(m) sum(ITEMS[order(-drivers[[m]])][1:3] %in% true_top3)),
  top_driver = sapply(method_cols, function(m) ITEMS[which.max(drivers[[m]])]),
  largest_rank_error = sapply(method_cols, function(m) max(abs(rank(-drivers[[m]]) - rank(-drivers$true_effect)))))
print(grade)

# ---- 3. Importance-performance matrix -------------------------------------------------------------------------------------
ipa <- drivers |> left_join(select(perf, item, top2box, mean_rating), by = "item") |>
  mutate(importance = relative_weight_share,
         quadrant = case_when(importance >= median(importance) & top2box < median(top2box) ~ "Fix first (important, weak)",
                              importance >= median(importance) ~ "Maintain (important, strong)",
                              top2box < median(top2box) ~ "Low priority (less important, weak)", TRUE ~ "Possible overkill (less important, strong)"))
print(select(ipa, label, importance, top2box, quadrant))

saveRDS(list(drivers = drivers, grade = grade, ipa = ipa, r2 = sum(rw)), "data/clean/driver_results.rds")

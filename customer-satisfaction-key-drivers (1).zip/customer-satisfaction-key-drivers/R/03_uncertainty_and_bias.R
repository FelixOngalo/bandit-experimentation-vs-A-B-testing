source("R/kda_functions.R")
library(tidyr)
set.seed(3)

obj <- readRDS("data/clean/survey_clean.rds"); d <- obj$data
truth <- readRDS("data/clean/truth.rds"); drv <- readRDS("data/clean/driver_results.rds")$drivers
X <- as.matrix(d[ITEMS]); y <- d$recommend; n <- nrow(d)

# ---- 1. Bootstrap: how stable are the driver estimates and their ranks? ----------------------------------
B <- 500
boot <- lapply(seq_len(B), function(b) {
  i <- sample(n, replace = TRUE); Xb <- X[i, ]; yb <- y[i]
  rw <- relative_weights(Xb, yb)
  list(beta = std_betas(Xb, yb), rw = rw / sum(rw))
})
beta_mat <- t(sapply(boot, `[[`, "beta")); rw_mat <- t(sapply(boot, `[[`, "rw"))
ci <- function(m, label) tibble(item = ITEMS, method = label, lower = apply(m, 2, quantile, 0.025), upper = apply(m, 2, quantile, 0.975)) |>
  mutate(width = upper - lower)
boot_ci <- bind_rows(ci(beta_mat, "std_beta"), ci(rw_mat, "relative_weight_share"))
print(boot_ci |> group_by(method) |> summarise(mean_ci_width = mean(width)))

top3_freq <- bind_rows(
  tibble(item = ITEMS, method = "std_beta", share_in_top3 = colMeans(t(apply(beta_mat, 1, function(r) ITEMS %in% ITEMS[order(-r)][1:3])))),
  tibble(item = ITEMS, method = "relative_weight_share", share_in_top3 = colMeans(t(apply(rw_mat, 1, function(r) ITEMS %in% ITEMS[order(-r)][1:3])))))
print(top3_freq |> pivot_wider(names_from = method, values_from = share_in_top3))

# ---- 2. Non-response: what does it do to NPS, and can a segment weight fix it? ----------------------------------
resp_rate <- weighted.mean(truth$response_rate$rate, obj$resp$customers[match(truth$response_rate$segment, obj$resp$segment)])
nps_resp <- nps(y)
scenario <- expand.grid(nonrespondent_nps_gap = c(0, -5, -10, -15, -20, -30)) |> as_tibble() |>
  mutate(implied_population_nps = resp_rate * nps_resp + (1 - resp_rate) * (nps_resp + nonrespondent_nps_gap))
cat("Overall response rate (simulation truth):", round(resp_rate, 3), "\n")
print(scenario)
needed_gap <- (truth$population_nps - nps_resp) / (1 - resp_rate)
cat("Gap between non-respondents and respondents that would explain the true NPS:", round(needed_gap, 1), "points\n")

saveRDS(list(boot_ci = boot_ci, top3_freq = top3_freq, scenario = scenario, resp_rate = resp_rate, needed_gap = needed_gap, B = B),
        "data/clean/uncertainty_results.rds")

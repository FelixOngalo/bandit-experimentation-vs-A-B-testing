# Functions for the customer-satisfaction key-driver project: a survey simulator with KNOWN driver effects
# and non-response bias, cleaning, NPS, relative weights, ordinal regression and bootstrap helpers.

library(dplyr)
library(tibble)

ITEMS <- c("quality", "value", "delivery", "support", "website", "returns", "comms", "brand")
ITEM_LABELS <- c(quality = "Product quality", value = "Value for money", delivery = "Delivery speed", support = "Customer support",
                 website = "Website ease of use", returns = "Returns process", comms = "Communication", brand = "Brand")

#' Simulate a customer survey. 4,000 customers; each has latent satisfaction with 8 aspects built from three
#' correlated factors (product / digital / service) plus a "halo" response style (some people rate everything higher).
#' The 0-10 "likelihood to recommend" depends on the aspects with KNOWN weights. Dissatisfied customers and
#' business customers are less likely to answer, so the observed sample is biased.
simulate_survey <- function(n = 4000, seed = 1, messy = TRUE) {
  set.seed(seed)
  fac  <- c(1, 2, 3, 3, 2, 3, 3, 1)                                   # product, digital, service
  b    <- c(0.50, 0.15, 0.35, 0.30, 0.10, 0.05, 0.20, 0.25)           # true effect of each aspect on the recommend score
  load <- c(0.80, 0.70, 0.75, 0.80, 0.70, 0.75, 0.80, 0.75)
  Sg <- matrix(c(1, .70, .65, .70, 1, .65, .65, .65, 1), 3)
  Fm <- matrix(rnorm(n * 3), n) %*% chol(Sg)
  halo <- rnorm(n, 0, 0.6)
  Zi <- sapply(seq_along(ITEMS), function(j) Fm[, fac[j]] * load[j] + rnorm(n, 0, sqrt(1 - load[j]^2)) + halo)
  business <- rbinom(n, 1, 0.35)
  over <- as.vector(Zi %*% b) + rnorm(n, 0, 0.8) + 0.3 * business + 0.5 * halo
  cz <- (over - mean(over)) / sd(over)
  recommend <- pmin(pmax(round(7.3 + 2.2 * cz + rnorm(n, 0, 0.6)), 0), 10)

  perf_shift <- c(0.3, -0.4, 0, -0.1, 0.2, -0.3, -0.2, 0.4); cuts <- c(-1.3, -0.5, 0.3, 1.1)
  rating <- sapply(seq_along(ITEMS), function(j) 1 + rowSums(outer(Zi[, j] + perf_shift[j], cuts, ">")))
  colnames(rating) <- ITEMS
  stated_mean <- c(4.2, 4.6, 4.5, 3.8, 3.2, 3.0, 3.1, 2.9)            # what people SAY matters (value and delivery top the list)
  stated <- sapply(stated_mean, function(m) pmin(pmax(round(m + rnorm(n, 0, 0.8)), 1), 5)); colnames(stated) <- paste0("imp_", ITEMS)

  responded <- rbinom(n, 1, plogis(-0.2 + 0.5 * cz - 0.6 * business)) == 1
  segment <- ifelse(business == 1, "Business", "Consumer")
  full <- tibble(respondent_id = sprintf("R%05d", seq_len(n)), segment = segment, as_tibble(rating), recommend = recommend, as_tibble(stated))
  population <- count(tibble(segment = segment), segment, name = "customers")
  truth <- list(
    population_nps = 100 * (mean(recommend >= 9) - mean(recommend <= 6)),
    response_rate = tibble(segment = c("Consumer", "Business"), rate = c(mean(responded[business == 0]), mean(responded[business == 1]))),
    effects = tibble(item = ITEMS, true_effect = b * apply(Zi, 2, sd) / sd(over)))    # standardised direct effect of each aspect
  raw <- full[responded, ]

  if (messy) {
    m <- nrow(raw)
    for (j in sample(ITEMS, 4)) raw[[j]][sample(m, round(0.015 * m))] <- 99                    # "don't know" coded as 99
    sl <- sample(m, round(0.03 * m)); const <- sample(1:5, length(sl), TRUE)                     # straight-liners
    for (j in ITEMS) raw[[j]][sl] <- const
    i_seg <- sample(m, 60); raw$segment[i_seg] <- tolower(raw$segment[i_seg])
    raw$recommend[sample(m, 25)] <- NA
    raw <- bind_rows(raw, raw[sample(m, 40), ])
  }
  list(raw = raw, population = population, truth = truth)
}

#' Clean: remove duplicates, standardise segment, treat 99 as missing, drop straight-liners (all eight ratings
#' identical) and rows without a recommend score, then drop rows with missing driver ratings.
clean_survey <- function(raw) {
  n0 <- nrow(raw)
  x <- distinct(raw); n_dup <- n0 - nrow(x)
  x$segment <- tools::toTitleCase(tolower(trimws(x$segment)))
  for (j in ITEMS) x[[j]][x[[j]] == 99] <- NA
  n_na_rating <- sum(rowSums(is.na(x[ITEMS])) > 0)
  sl <- apply(x[ITEMS], 1, function(r) !anyNA(r) && length(unique(r)) == 1)
  n_sl <- sum(sl); x <- x[!sl, ]
  n_nr <- sum(is.na(x$recommend)); x <- x[!is.na(x$recommend), ]
  x <- x[complete.cases(x[ITEMS]), ]
  x$nps_group <- cut(x$recommend, c(-1, 6, 8, 10), labels = c("Detractor", "Passive", "Promoter"), ordered_result = TRUE)
  log <- tibble(step = c("Responses received", "Duplicates removed", "Responses with a 'don't know' rating", "Straight-liners removed",
                         "Missing recommend score removed", "Complete responses analysed"),
                rows = c(n0, n_dup, n_na_rating, n_sl, n_nr, nrow(x)))
  list(data = x, log = log)
}

#' Net Promoter Score: % promoters (9-10) minus % detractors (0-6), optionally weighted.
nps <- function(r, w = rep(1, length(r))) 100 * (sum(w * (r >= 9)) - sum(w * (r <= 6))) / sum(w)

#' Johnson's relative weights: the share of explained variance attributable to each (correlated) predictor,
#' computed via the closest orthogonal approximation of the predictor matrix.
relative_weights <- function(X, y) {
  R <- cor(X); e <- eigen(R, symmetric = TRUE)
  L <- e$vectors %*% diag(sqrt(e$values)) %*% t(e$vectors)
  beta <- solve(L, cor(X, y)[, 1])
  w <- as.vector((L^2) %*% (beta^2)); names(w) <- colnames(X)
  w
}

std_betas <- function(X, y) {
  Xs <- scale(X); ys <- as.vector(scale(y))
  b <- lm.fit(cbind(1, Xs), ys)$coefficients[-1]; names(b) <- colnames(X); b
}

# Customer Satisfaction Key Driver Analysis in R: What Really Drives Recommendation?

Customers say that price and delivery matter most, but do those aspects actually move recommendation? This project analyses a customer satisfaction survey with the methods used in practice (correlation, regression, relative weights, ordinal logit) and grades each against the *known truth* in a simulation. It also shows how non-response biases the Net Promoter Score (NPS) and why a simple segment weight does not fix it.

## Question

Eight aspects of a business are rated 1 to 5, along with "how likely are you to recommend us" (0 to 10). Which aspects genuinely drive recommendation, how far off is what customers *say* is important, how much can we trust the ranking, and what is the real NPS given that only about 40% of customers answered?

## Key findings

*(Fill in after running the scripts. Suggested: respondent NPS, weighted NPS and the true population NPS; the response rate and the gap the non-respondents would need to explain the difference; Spearman correlation and top-3 accuracy for each method against the true effects; the aspects where stated importance is most wrong; the "fix first" quadrant; bootstrap interval widths and top-3 frequencies.)*

## What is in it

- **Simulated survey** for 4,000 customers with three correlated factors, a halo response style, known driver effects and informative non-response. Messy raw data: "don't know" codes (99), straight-liners, duplicates, inconsistent labels and missing scores.
- **Cleaning** with a log of every step.
- **NPS** with segment weighting and a bootstrap interval, and a **non-response sensitivity table** showing what the population NPS would be under different assumptions about non-respondents.
- **Collinearity diagnostics**: correlation matrix, variance inflation factors and a three-factor analysis.
- **Five driver methods**: stated importance, correlation, standardised regression coefficients, Johnson's relative weights (from scratch) and ordinal logit (`MASS::polr`).
- **Grading against the truth**: Spearman correlation, top-3 hits and largest rank error for each method.
- **Importance-performance matrix** to turn the results into priorities.
- **Bootstrap** intervals and top-3 stability for regression and relative weights.
- **A Quarto report** with the method, charts and limitations.

## Tools

R, dplyr, tidyr, tibble, ggplot2, knitr, Quarto, and `MASS` (included with R) for ordinal regression.

## Reproduce

```r
install.packages(c("dplyr", "tidyr", "tibble", "ggplot2", "knitr"))
source("R/00_simulate_data.R")
source("R/01_clean_explore.R")
source("R/02_driver_analysis.R")
source("R/03_uncertainty_and_bias.R")
quarto::quarto_render("reports/report.qmd")
```

Run from the project root (open `customer-satisfaction-key-drivers.Rproj`). The seeds are fixed, so results are reproducible.

## Project structure

```
customer-satisfaction-key-drivers/
├── R/
│   ├── kda_functions.R           # simulator, cleaning, NPS, relative weights, helpers
│   ├── 00_simulate_data.R
│   ├── 01_clean_explore.R
│   ├── 02_driver_analysis.R
│   └── 03_uncertainty_and_bias.R
├── data/
│   ├── raw/                      # survey_responses.csv, customers_by_segment.csv (generated)
│   └── clean/                    # .rds results (generated)
├── reports/report.qmd
├── customer-satisfaction-key-drivers.Rproj
└── README.md
```

## Limitations

- Simulated data with a linear structure; real surveys have non-linearities, ceiling effects and fatigue.
- Driver analysis shows association, not that improving an aspect will raise recommendation.
- Relative weights compress differences; use them to prioritise, not as effect sizes.
- Segment weighting cannot fix non-response that depends on satisfaction itself.
- Simple straight-liner rule; "don't know" answers are dropped, not modelled.

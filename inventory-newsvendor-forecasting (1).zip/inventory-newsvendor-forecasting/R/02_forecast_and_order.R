source("R/inventory_functions.R")
library(tidyr)
set.seed(2)

obj <- readRDS("data/clean/inventory_clean.rds"); d <- obj$data; profile <- obj$profile
truth <- readRDS("data/clean/truth_demand.rds")
d <- left_join(d, truth, by = c("sku", "week_start"))
test_weeks <- (N_TRAIN + 1):max(d$week)

# ---- Forecast every SKU for the test period and compute order quantities under five policies ----
rows <- lapply(profile$sku, function(s) {
  ds <- d[d$sku == s, ]; tr <- ds[ds$week <= N_TRAIN, ]; te <- ds[ds$week > N_TRAIN, ]
  p <- profile[profile$sku == s, ]; cr <- p$critical_ratio
  fit <- fit_demand(tr$week, tr$promo, tr$units)
  mu_hat <- predict_mean(fit, te$week, te$promo)
  last8 <- tail(tr$units, 8); cro <- croston_sba(tr$units)
  tibble(sku = s, week = te$week, demand = te$units, mu_true = te$mu, size_true = te$size, mu_hat = mu_hat, size_hat = fit$size,
         underage_cost = p$underage_cost, overage_cost = p$overage_cost, critical_ratio = cr, demand_class = p$demand_class,
         q_rule = pmax(0, round(qnorm(cr) * sd(last8) + mean(last8))),
         q_croston = pmax(0, round(cro + qnorm(cr) * sd(tr$units))),
         q_nbreg = qnbinom(cr, size = fit$size, mu = mu_hat),
         q_nb95 = qnbinom(0.95, size = fit$size, mu = mu_hat),
         q_oracle = qnbinom(cr, size = te$size, mu = te$mu))
})
fc <- bind_rows(rows)
policy_names <- c(rule = "Rule of thumb (last 8 weeks, normal)", croston = "Croston-SBA + normal",
                  nbreg = "Regression + NB, cost-based quantile", nb95 = "Regression + NB, flat 95% service", oracle = "Oracle (true demand law)")

long <- fc |> pivot_longer(starts_with("q_"), names_to = "policy", names_prefix = "q_", values_to = "q") |>
  mutate(tau = ifelse(policy == "nb95", 0.95, critical_ratio),
         realised_cost = cost_of_order(q, demand, underage_cost, overage_cost),
         expected_cost = mapply(expected_cost_true, q, mu_true, size_true, underage_cost, overage_cost),
         pinball_loss = pinball(q, demand, tau), covered = demand <= q,
         sold = pmin(demand, q), under_cost = underage_cost * pmax(demand - q, 0), over_cost = overage_cost * pmax(q - demand, 0),
         policy_label = policy_names[policy])

summary_tbl <- long |> group_by(policy_label, policy) |> summarise(
  expected_cost_per_sku_week = mean(expected_cost), realised_cost_per_sku_week = mean(realised_cost),
  fill_rate = sum(sold) / sum(demand), service_level = mean(covered), pinball = mean(pinball_loss),
  stockout_cost = mean(under_cost), overstock_cost = mean(over_cost), .groups = "drop") |>
  mutate(excess_cost_vs_oracle = expected_cost_per_sku_week / expected_cost_per_sku_week[policy == "oracle"] - 1) |>
  arrange(expected_cost_per_sku_week)
print(summary_tbl)

# ---- Forecast accuracy of the mean and the dispersion --------------------------------------------
acc <- fc |> group_by(demand_class) |> summarise(skus = n_distinct(sku), mean_demand = mean(demand),
  mae_regression = mean(abs(demand - mu_hat)), mae_true_mean = mean(abs(demand - mu_true)),
  size_hat = median(size_hat), size_true = median(size_true), .groups = "drop")
print(acc)

saveRDS(list(fc = fc, long = long, summary_tbl = summary_tbl, acc = acc, policy_names = policy_names), "data/clean/forecast_results.rds")

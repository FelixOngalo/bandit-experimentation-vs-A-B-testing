source("R/uplift_functions.R")
set.seed(1)

raw <- read.csv("data/raw/campaign_experiment.csv", stringsAsFactors = FALSE)
cleaned <- clean_uplift(raw); d <- cleaned$data
print(cleaned$log)
stopifnot(nrow(d) == 20000, all(d$treated %in% 0:1), !anyNA(d[FEATURES]))

# ---- Was the experiment randomised properly? Standardised mean differences by arm ------------
smd_of <- function(v) { a <- v[d$treated == 1]; b <- v[d$treated == 0]; (mean(a) - mean(b)) / sqrt((var(a) + var(b)) / 2) }
smd <- tibble(variable = c(FEATURES, "region_South", "region_East", "region_West"),
              smd = c(sapply(FEATURES, function(v) smd_of(d[[v]])),
                      sapply(c("South", "East", "West"), function(r) smd_of(as.numeric(d$region == r)))))
print(smd)

# ---- The average treatment effect: is the campaign worth running at all? ----------------------
arm <- d |> group_by(treated) |> summarise(n = n(), conversion = mean(converted), .groups = "drop")
print(arm)
p1 <- arm$conversion[arm$treated == 1]; p0 <- arm$conversion[arm$treated == 0]
n1 <- arm$n[arm$treated == 1]; n0 <- arm$n[arm$treated == 0]
ate <- p1 - p0; se <- sqrt(p1 * (1 - p1) / n1 + p0 * (1 - p0) / n0)
ate_tbl <- tibble(ate = ate, lower = ate - 1.96 * se, upper = ate + 1.96 * se,
                  profit_per_customer_treat_all = MARGIN * ate - COST)
print(ate_tbl)

# ---- Observed uplift by simple segments (what an analyst would look at first) -----------------
seg <- d |> mutate(segment = case_when(tenure_months < 15 & recency_days > 25 ~ "New and lapsed",
                                      visits_30d >= 6 & past_spend > 150 ~ "Heavy loyal buyers", TRUE ~ "Everyone else")) |>
  group_by(segment) |> summarise(n = n(), conv_treated = mean(converted[treated == 1]), conv_control = mean(converted[treated == 0]),
                                 uplift = conv_treated - conv_control, .groups = "drop")
print(seg)

saveRDS(list(data = d, log = cleaned$log, smd = smd, arm = arm, ate = ate_tbl, seg = seg), "data/clean/uplift_clean.rds")

source("R/uplift_functions.R")
library(tidyr)
set.seed(2)

obj <- readRDS("data/clean/uplift_clean.rds"); d <- obj$data
truth <- readRDS("data/clean/truth_uplift.rds")
d <- left_join(d, truth, by = "customer_id")

idx <- sample(nrow(d), round(0.7 * nrow(d)))
train <- d[idx, ]; test <- d[-idx, ]
scores <- fit_uplift_models(train, test)
scores$oracle <- test$true_uplift
scores$random <- runif(nrow(test))

# ---- 1. Qini coefficients and how well each score ranks the TRUE uplift -----------------------
methods <- names(scores)
qtab <- tibble(method = methods,
  qini_coefficient = sapply(methods, function(m) qini_coef(scores[[m]], test$treated, test$converted)),
  spearman_with_true_uplift = sapply(methods, function(m) cor(scores[[m]], test$true_uplift, method = "spearman")),
  true_uplift_top20 = sapply(methods, function(m) mean(test$true_uplift[top_share(scores[[m]], 0.2)])),
  true_uplift_bottom20 = sapply(methods, function(m) mean(test$true_uplift[top_share(-scores[[m]], 0.2)]))) |>
  mutate(share_of_oracle_qini = qini_coefficient / qini_coefficient[method == "oracle"])
print(qtab)

curves <- bind_rows(lapply(methods, function(m) mutate(qini_curve(scores[[m]], test$treated, test$converted), method = m)))

# ---- 2. Are the uplift estimates calibrated? Predicted versus observed uplift by decile --------
calib <- bind_rows(lapply(c("s_learner", "t_learner"), function(m) {
  test |> mutate(score = scores[[m]], decile = ntile(-score, 10)) |> group_by(decile) |>
    summarise(predicted = mean(score), observed = mean(converted[treated == 1]) - mean(converted[treated == 0]),
              truth = mean(true_uplift), .groups = "drop") |> mutate(method = m)
}))
print(calib)

saveRDS(list(qtab = qtab, curves = curves, calib = calib, scores = scores, test = test, train_n = nrow(train)), "data/clean/model_results.rds")

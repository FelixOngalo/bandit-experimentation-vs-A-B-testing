source("R/uplift_functions.R")
library(tidyr)
set.seed(3)

res <- readRDS("data/clean/model_results.rds"); test <- res$test; scores <- res$scores
tu <- test$true_uplift; thr <- COST / MARGIN
cat("Break-even uplift (cost / margin):", thr, "\n")

# ---- 1. Policies ------------------------------------------------------------------------------
n <- nrow(test)
policies <- list(
  "Treat nobody" = rep(FALSE, n), "Treat everybody" = rep(TRUE, n),
  "Top 30% by response model" = top_share(scores$response, 0.3),
  "Top 30% by S-learner" = top_share(scores$s_learner, 0.3),
  "Top 30% by T-learner" = top_share(scores$t_learner, 0.3),
  "Top 30% by transformed outcome" = top_share(scores$transformed_outcome, 0.3),
  "S-learner: treat if uplift > break-even" = scores$s_learner > thr,
  "T-learner: treat if uplift > break-even" = scores$t_learner > thr,
  "Oracle: treat if true uplift > break-even" = tu > thr)
pol <- tibble(policy = names(policies),
  share_treated = sapply(policies, mean),
  true_profit_per_customer = sapply(policies, true_policy_value, true_uplift = tu),
  observed_profit_per_customer = sapply(policies, observed_policy_value, treated = test$treated, y = test$converted)) |>
  mutate(share_of_oracle_profit = true_profit_per_customer / true_profit_per_customer[policy == "Oracle: treat if true uplift > break-even"])
print(pol)

# ---- 2. Profit against the share of customers contacted ---------------------------------------
shares <- seq(0, 1, by = 0.05)
budget <- bind_rows(lapply(c("response", "s_learner", "t_learner", "transformed_outcome", "oracle"), function(m)
  tibble(method = m, share = shares, profit = sapply(shares, function(s) true_policy_value(top_share(scores[[m]], s), tu)))))
best <- budget |> group_by(method) |> slice_max(profit, n = 1, with_ties = FALSE) |> ungroup()
print(best)

# ---- 3. Bootstrap: is the uplift model reliably better than the response model? ---------------
B <- 200; ids <- seq_len(n)
boot <- bind_rows(lapply(seq_len(B), function(b) {
  i <- sample(ids, replace = TRUE); tt <- test$treated[i]; yy <- test$converted[i]
  q <- sapply(c("response", "s_learner", "t_learner", "transformed_outcome"), function(m) qini_coef(scores[[m]][i], tt, yy))
  tibble(rep = b, response = q[["response"]], s_learner = q[["s_learner"]], t_learner = q[["t_learner"]],
         transformed_outcome = q[["transformed_outcome"]],
         s_minus_response = q[["s_learner"]] - q[["response"]], t_minus_s = q[["t_learner"]] - q[["s_learner"]])
}))
boot_summary <- boot |> pivot_longer(-rep, names_to = "quantity", values_to = "value") |> group_by(quantity) |>
  summarise(mean = mean(value), lower = quantile(value, 0.025), upper = quantile(value, 0.975), .groups = "drop")
print(boot_summary)

saveRDS(list(pol = pol, budget = budget, best = best, boot_summary = boot_summary, thr = thr, B = B), "data/clean/policy_results.rds")

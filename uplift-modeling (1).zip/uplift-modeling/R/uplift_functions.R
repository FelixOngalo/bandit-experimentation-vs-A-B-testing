# Functions for the uplift-modelling project: a simulated randomised campaign with KNOWN individual
# effects, cleaning, four targeting models, Qini/AUUC evaluation and profit-based targeting policies.

library(dplyr)
library(tibble)

MARGIN <- 20    # profit per conversion ($)
COST   <- 0.60  # cost of contacting one customer ($)

plogis2 <- function(x) 1 / (1 + exp(-x))

#' Simulate a randomised campaign (50% treated). Each customer has a baseline conversion probability p0
#' and a treated probability p1; true uplift = p1 - p0 varies by customer: "persuadables" (new, lapsed),
#' "sleeping dogs" (heavy, loyal buyers who are put off by contact) and everyone in between.
simulate_uplift <- function(n = 20000, seed = 1, messy = TRUE) {
  set.seed(seed)
  age <- runif(n, 18, 70); tenure <- rgamma(n, 2, scale = 10)
  spend <- rgamma(n, 2, scale = 60) * (1 + tenure / 60)
  recency <- rexp(n, 1 / 30); visits <- rpois(n, 3 + spend / 150)
  region <- sample(c("North", "South", "East", "West"), n, replace = TRUE)
  z <- function(v) (v - mean(v)) / sd(v)

  base_logit <- -2.2 + 0.5 * z(log1p(spend)) + 0.4 * z(visits) - 0.4 * z(recency) + 0.2 * (region == "South")
  tau_logit  <- 0.9 * (tenure < 15 & recency > 25) + 0.25 * z(-age) + 0.3 * (region == "East") -
                0.9 * (visits >= 6 & spend > 150)
  p0 <- plogis2(base_logit); p1 <- plogis2(base_logit + tau_logit)
  treated <- rbinom(n, 1, 0.5)
  converted <- rbinom(n, 1, ifelse(treated == 1, p1, p0))

  raw <- tibble(customer_id = sprintf("C%05d", seq_len(n)), age = round(age, 1), tenure_months = round(tenure, 1),
                past_spend = round(spend, 2), recency_days = round(recency, 1), visits_30d = visits,
                region = region, treated = ifelse(treated == 1, "Y", "N"), converted = converted)
  truth <- tibble(customer_id = raw$customer_id, p0 = p0, p1 = p1, true_uplift = p1 - p0)

  if (messy) {
    raw$past_spend[sample(n, round(0.03 * n))] <- NA                                   # missing spend
    raw$age[sample(n, 15)] <- 999                                                      # impossible ages
    i_case <- sample(n, 400); raw$region[i_case] <- tolower(raw$region[i_case])        # inconsistent case
    i_ws <- sample(n, 300); raw$region[i_ws] <- paste0(" ", raw$region[i_ws])          # stray whitespace
    raw <- bind_rows(raw, raw[sample(n, 30), ])                                        # duplicated rows
  }
  list(raw = raw, truth = truth)
}

#' Clean: remove duplicates, fix region labels, set impossible ages to missing, median-impute numeric gaps
#' (with a missing-spend flag), recode treatment.
clean_uplift <- function(raw) {
  n0 <- nrow(raw)
  x <- distinct(raw)
  n_dup <- n0 - nrow(x)
  x$region <- tools::toTitleCase(tolower(trimws(x$region)))
  n_age <- sum(x$age > 100, na.rm = TRUE); x$age[x$age > 100] <- NA
  n_spend <- sum(is.na(x$past_spend)); n_age_na <- sum(is.na(x$age))
  x$spend_missing <- as.integer(is.na(x$past_spend))
  for (v in c("age", "past_spend")) x[[v]][is.na(x[[v]])] <- median(x[[v]], na.rm = TRUE)
  x$treated <- as.integer(x$treated == "Y")
  x$log_spend <- log1p(x$past_spend)
  log <- tibble(step = c("Rows received", "Duplicate rows removed", "Region labels standardised",
                         "Impossible ages set to missing", "Missing values median-imputed (age + spend)", "Customers analysed"),
                rows = c(n0, n_dup, length(unique(x$region)), n_age, n_spend + n_age_na, nrow(x)))
  list(data = x, log = log)
}

FEATURES <- c("age", "tenure_months", "log_spend", "recency_days", "visits_30d")

#' Design matrix: standardised numeric features (scaling from `ref`), squares, all pairwise
#' interactions and region dummies. The same `ref` must be used for every dataset that is scored.
make_design <- function(d, ref = d) {
  Z <- sapply(FEATURES, function(v) (d[[v]] - mean(ref[[v]])) / sd(ref[[v]])); colnames(Z) <- FEATURES
  reg <- sapply(c("South", "East", "West"), function(r) as.numeric(d$region == r))
  base <- cbind(Z, reg)
  sq <- Z^2; colnames(sq) <- paste0(FEATURES, "_sq")
  idx <- combn(ncol(base), 2)
  ix <- sapply(seq_len(ncol(idx)), function(k) base[, idx[1, k]] * base[, idx[2, k]])
  colnames(ix) <- paste0("ix", seq_len(ncol(ix)))
  cbind(base, sq, ix)
}

fit_logit <- function(X, y) {
  b <- suppressWarnings(glm.fit(cbind(1, X), y, family = binomial(), control = list(maxit = 50)))$coefficients
  b[is.na(b)] <- 0          # columns that are always zero (e.g. South x East dummies) get no weight
  b
}
pred_logit <- function(b, X) plogis2(cbind(1, X) %*% b)[, 1]

#' Fit the four targeting models on training data and score `test`.
#'  response: P(convert | x) fitted on TREATED customers only (the usual "propensity to buy" model)
#'  S-learner: one model with treatment and treatment x features; uplift = P(x, T=1) - P(x, T=0)
#'  T-learner: separate models for treated and control; uplift = difference
#'  transformed outcome: regress Y* = Y (T - e) / (e (1 - e)) on x; E[Y* | x] equals the uplift
fit_uplift_models <- function(train, test) {
  Xtr <- make_design(train, train); Xte <- make_design(test, train)
  t <- train$treated; y <- train$converted; e <- mean(t)
  b_resp <- fit_logit(Xtr[t == 1, ], y[t == 1])
  resp <- pred_logit(b_resp, Xte)

  bS <- fit_logit(cbind(Xtr, t, Xtr * t), y)
  S <- pred_logit(bS, cbind(Xte, 1, Xte)) - pred_logit(bS, cbind(Xte, 0, Xte * 0))

  b1 <- fit_logit(Xtr[t == 1, ], y[t == 1]); b0 <- fit_logit(Xtr[t == 0, ], y[t == 0])
  Tl <- pred_logit(b1, Xte) - pred_logit(b0, Xte)

  ystar <- y * (t - e) / (e * (1 - e))
  bT <- lm.fit(cbind(1, Xtr), ystar)$coefficients; bT[is.na(bT)] <- 0
  TO <- as.numeric(cbind(1, Xte) %*% bT)
  tibble(response = resp, s_learner = S, t_learner = Tl, transformed_outcome = TO)
}

#' Qini curve: cumulative incremental conversions when targeting the top-k customers by score,
#' estimated from the randomised data as  Y_T(k) - Y_C(k) * N_T(k) / N_C(k).
qini_curve <- function(score, treated, y) {
  o <- order(score, decreasing = TRUE); tt <- treated[o]; yy <- y[o]
  nt <- cumsum(tt); nc <- cumsum(1 - tt); yt <- cumsum(yy * tt); yc <- cumsum(yy * (1 - tt))
  q <- yt - yc * nt / pmax(nc, 1)
  tibble(frac = seq_along(q) / length(q), qini = q)
}

#' Qini coefficient: area between the Qini curve and the straight line of random targeting (per customer).
qini_coef <- function(score, treated, y) {
  qc <- qini_curve(score, treated, y); n <- nrow(qc)
  rand <- qc$qini[n] * qc$frac
  sum((qc$qini - rand)[-1] + (qc$qini - rand)[-n]) / 2 / n / n    # trapezoid in frac, scaled per customer
}

#' Observed (randomised-data) estimate of the profit per customer of treating the selected customers.
observed_policy_value <- function(select, treated, y, margin = MARGIN, cost = COST) {
  tt <- treated[select]; yy <- y[select]
  if (sum(tt) == 0 || sum(1 - tt) == 0) return(NA_real_)
  uplift_hat <- mean(yy[tt == 1]) - mean(yy[tt == 0])
  (margin * uplift_hat - cost) * sum(select) / length(select)
}

#' True profit per customer of a policy (uses the simulated true uplift).
true_policy_value <- function(select, true_uplift, margin = MARGIN, cost = COST) sum((margin * true_uplift - cost)[select]) / length(select)

top_share <- function(score, share) { sel <- rep(FALSE, length(score)); sel[order(score, decreasing = TRUE)[seq_len(round(share * length(score)))]] <- TRUE; sel }
